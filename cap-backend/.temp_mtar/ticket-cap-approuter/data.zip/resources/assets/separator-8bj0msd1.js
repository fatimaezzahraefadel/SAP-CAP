import{c as d,r as p,j as n,P as v,W as x}from"./index-WCyyBkOK.js";/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]],E=d("circle-alert",u);var y="Separator",e="horizontal",f=["horizontal","vertical"],c=p.forwardRef((r,t)=>{const{decorative:o,orientation:a=e,...s}=r,i=h(a)?a:e,l=o?{role:"none"}:{"aria-orientation":i==="vertical"?i:void 0,role:"separator"};return n.jsx(v.div,{"data-orientation":i,...l,...s,ref:t})});c.displayName=y;function h(r){return f.includes(r)}var m=c;function k({className:r,orientation:t="horizontal",decorative:o=!0,...a}){return n.jsx(m,{"data-slot":"separator-root",decorative:o,orientation:t,className:x("bg-border shrink-0 data-[orientation=horizontal]:h-px data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-px",r),...a})}export{E as C,k as S};
