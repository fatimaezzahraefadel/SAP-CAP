import{c as s,u as N,j as e,C as w,b as M,a6 as _,m as C,T as g,a2 as T,U as $,d as q,W as p,a as z,B as F}from"./index-WCyyBkOK.js";import{P as U}from"./progress-Bg8IlXCr.js";import{F as B}from"./file-text-CLK4ikAc.js";/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=[["path",{d:"m7 7 10 10",key:"1fmybs"}],["path",{d:"M17 7v10H7",key:"6fjiku"}]],L=s("arrow-down-right",H);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P=[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]],A=s("arrow-up-right",P);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=[["path",{d:"M12 12h.01",key:"1mp3jc"}],["path",{d:"M16 6V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2",key:"1ksdt3"}],["path",{d:"M22 13a18.15 18.15 0 0 1-20 0",key:"12hx5q"}],["rect",{width:"20",height:"14",x:"2",y:"6",rx:"2",key:"i6l2r4"}]],K=s("briefcase-business",I);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16.5 12",key:"1aq6pp"}]],V=s("clock-3",R);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}],["path",{d:"M12 7v5l4 2",key:"1fdv2h"}]],W=s("history",S);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=[["rect",{x:"3",y:"5",width:"6",height:"6",rx:"1",key:"1defrl"}],["path",{d:"m3 17 2 2 4-4",key:"1jhpwq"}],["path",{d:"M13 6h8",key:"15sg57"}],["path",{d:"M13 12h8",key:"h98zly"}],["path",{d:"M13 18h8",key:"oe0vm4"}]],E=s("list-todo",D);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=[["path",{d:"M7 18v-6a5 5 0 1 1 10 0v6",key:"pcx96s"}],["path",{d:"M5 21a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-1a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2z",key:"1b4s83"}],["path",{d:"M21 12h1",key:"jtio3y"}],["path",{d:"M18.5 4.5 18 5",key:"g5sp9y"}],["path",{d:"M2 12h1",key:"1uaihz"}],["path",{d:"M12 2v1",key:"11qlp1"}],["path",{d:"m4.929 4.929.707.707",key:"1i51kw"}],["path",{d:"M12 12v6",key:"3ahymv"}]],J=s("siren",G);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]],Q=s("trending-up",O),X={group:$,task:E,"project-definition-triangle-2":T,alert:g,warning:g,timesheet:V,"trend-up":Q,document:B,accept:C,incident:J,history:W,performance:_,"business-objects-experience":K},Y=(o,a)=>{const r=(o??a??"").toLowerCase();return r.includes("good")||r.includes("positive")||r==="green"?{chip:"bg-primary/12 text-primary",value:"text-primary",border:"border-primary/35",progress:"var(--color-primary)"}:r.includes("error")||r.includes("negative")||r==="red"?{chip:"bg-destructive/12 text-destructive",value:"text-destructive",border:"border-destructive/35",progress:"var(--color-destructive)"}:r.includes("critical")||r.includes("warning")||r==="yellow"||r==="orange"?{chip:"bg-accent text-accent-foreground",value:"text-accent-foreground",border:"border-accent",progress:"var(--color-chart-5)"}:{chip:"bg-primary/10 text-primary",value:"text-primary",border:"border-primary/30",progress:"var(--color-primary)"}},se=({title:o,value:a,subtitle:r,unit:h,icon:n,variant:f="default",color:b,progress:m,trend:x="None",state:k,target:t,deviation:i})=>{const{t:u}=N(),y=typeof n=="string"?X[n]:n,j=k??{default:"positive",info:"positive",warning:"warning",danger:"error",success:"good"}[f],c=Y(j,b),v=typeof a=="number"?a:Number(a),d=typeof t=="number"?t:Number(t),l=m!==void 0?m:Number.isFinite(v)&&Number.isFinite(d)&&d>0?v/d*100:void 0;return e.jsxs(w,{className:p("overflow-hidden border bg-card/95 shadow-none transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-primary/5",c.border),children:[e.jsxs(M,{className:"relative pb-2",children:[e.jsx("div",{className:"pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/35 to-transparent"}),e.jsxs("div",{className:"flex items-start justify-between gap-3",children:[e.jsxs("div",{children:[e.jsx(q,{className:"text-sm font-semibold uppercase tracking-[0.08em] text-muted-foreground",children:o}),r&&e.jsx("p",{className:"mt-1 text-xs text-muted-foreground",children:r})]}),y&&e.jsx("span",{className:p("inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/40 shadow-sm",c.chip),children:e.jsx(y,{className:"h-4 w-4"})})]})]}),e.jsxs(z,{className:"space-y-3",children:[e.jsxs("div",{className:"flex items-end gap-2",children:[e.jsx("span",{className:p("text-3xl font-semibold tracking-tight",c.value),children:a}),h&&e.jsx("span",{className:"pb-1 text-sm text-muted-foreground",children:h}),x!=="None"&&e.jsx("span",{className:"pb-1",children:x==="Up"?e.jsx(A,{className:"h-4 w-4 text-primary"}):e.jsx(L,{className:"h-4 w-4 text-destructive"})})]}),(i||t!==void 0)&&e.jsxs("div",{className:"flex flex-wrap items-center gap-2 text-xs text-muted-foreground",children:[i&&e.jsx(F,{variant:"secondary",className:"font-normal",children:i}),t!==void 0&&e.jsx("span",{children:u("common.targetWithValue",{value:t})})]}),l!==void 0&&e.jsxs("div",{className:"space-y-1.5",children:[t!==void 0&&e.jsxs("div",{className:"flex items-center justify-between text-[10px] uppercase tracking-wider text-muted-foreground",children:[e.jsx("span",{children:u("common.progressToTarget")}),e.jsxs("span",{children:[Math.round(l),"%"]})]}),e.jsx(U,{value:Math.max(0,Math.min(100,l)),className:"h-1.5 bg-muted/80"})]})]})]})};export{V as C,se as K};
